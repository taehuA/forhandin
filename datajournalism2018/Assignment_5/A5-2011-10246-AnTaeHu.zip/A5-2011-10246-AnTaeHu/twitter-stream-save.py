import tweepy
import json

consumer_key = '7WXooOrqb7CvYiqjdzxWQOXVV'
consumer_secret = 'XIRcbSt4CclH4tJcDIkLlk5k0e4Eqt1BKwmwuwGoMM6qq3h297'
access_token = '765212538262786048-EQwG1AlQFlZonyG1pkmYH7mweWR7YxW'
access_secret = 'LWSZM3c89P0oojBmmA9zW7SENFwYmLxnutJ7coEiiSwXu'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

class MyListener(tweepy.StreamListener):
    def on_status(self, data):
        print(data.text + "\n----")
    def on_data(self, data):
        try:
            with open('tweet_stream.json', 'a', newline = "\n") as file:
                file.write(data)
                print(data)
                return True
        except BaseException as e:
            print("Error on_data: {}".format(str(e)))
        return True

twitter_stream = tweepy.Stream(auth, MyListener())
twitter_stream.filter(track=['이수역'])
